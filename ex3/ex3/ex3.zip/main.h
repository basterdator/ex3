#ifndef __MAIN_H__
#define __MAIN_H__


// Includes --------------------------------------------------------------------
#include <windows.h>

// Constants  ------------------------------------------------------------------


HANDLE laundry_room;
HANDLE laundry_full;
HANDLE laundry_empy;
HANDLE write_to_file;
int NUM_OF_ROOMMATES = 10;
int M = 10;
int num_of_active_roomates = 10;
int num_of_clothes_in_basket = 0;

#endif // __MAIN_H__
