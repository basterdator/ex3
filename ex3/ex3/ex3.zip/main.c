/* ==============================================
Introduction to Systems Programming
Winter 2017-2018
TEL-AVIV UNIVERSITY
Exercise 3
Uri Cohen                 302825807
Anton Chaplianka          310224209
============================================== */

// Includes --------------------------------------------------------------------
#include "Roommate.h"
#include "LaundryBot.h"
#include "PrintToFile.h"
#include "Timer.h"
#include "main.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <windows.h>

// Constants  ------------------------------------------------------------------


int main(int argc, char *argv[]) 
{
	
	PrintToFile("Yo\n", 1);
	return 0;

}

//static void WashRoom()
//{
//
//
//}